#!/bin/sh
nohup python app.py &
